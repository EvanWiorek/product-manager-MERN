import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";

export default ({ products }) => {
  // console.log(products[0]._id);

  return (
    <div className="col-10 m-auto">
      {/* <div className="card"> */}

      <table className="table table-bordered table-hover my-shadow">
        <thead>
          <tr>
            <th scope="col">
              <h2 className="text-center">All Products</h2>
            </th>
          </tr>
        </thead>
        <tbody>
          {products.map((product, i) => (
            <tr>
              <td key={i} className="p-3">
                <h5>
                  <Link to={`/product/${product._id}`}>{product.title}</Link>
                </h5>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    // </div>
  );
};
